
from resources.lib import main
    
main.run()
